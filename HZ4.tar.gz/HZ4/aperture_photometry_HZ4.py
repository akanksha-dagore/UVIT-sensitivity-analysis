import os
import photutils
import shutil

import astropy.io.fits as fits
import numpy as np

from astropy.stats import SigmaClip
from glob import glob
from photutils.aperture import CircularAperture
from photutils.centroids import centroid_com



#-----------------------------------------------------------------------------



# DEFINING FUNCTIONS


def rebin(arr, bin_factor):
    shape = (int(arr.shape[0] / bin_factor), bin_factor,
             int(arr.shape[1] / bin_factor), bin_factor)
    binned_arr = arr.reshape(shape).mean(-1).mean(1)
    return binned_arr


def tile_array(arr, factor):
    m, n = arr.shape
    return np.repeat(np.repeat(arr, factor, axis = 1), factor, 
                     axis = 0).reshape(m * factor, n * factor)



#------------------------------------------------------------------------------



# FETCHING THE DATA



obs_list_path = "Data_info/obs_id.txt"
with open(obs_list_path, 'r') as file:
    data = file.readlines()
file.close()


obs = [i.strip() for i in data]

img_orbit = []
total_img = 0
exp_time_threshold = 130


for i in obs:
    img = glob("Data_astrobrowse/" + i + "/*FIIP*F1I_l2img.fits.gz")
    episode_index = []
    
    if len(img) == 1:
        img_orbit.append(img)
    else:
        for index, k in enumerate(img):
            img_list = fits.open(k)
            exp_time = img_list[0].header['EXP_TIME']
            if exp_time > exp_time_threshold:
                episode_index.append(index)
        temp_arr = []
        
        """ 
        These exposure time values were removed:
        AS1C02_002T01_9000000888 uvt_12 - 69.22363
        AS1C02_002T01_9000006092 uvt_09 - 119.3006
        
        """
        
        for a in episode_index:
            temp_arr.append(img[a])
        img_orbit.append(temp_arr)


total_img = sum(len(i) for i in img_orbit)
print("Instrument coordinate images for all episodes: ", total_img)
print("______________________________________________________________________")
print("")


imgI_coo_dat_file_orbit = [["source_detection/" + str(obs[idx]) + "/" + 
                            img[-58:-52] + "_coo_imgI.dat" for img in orbit] 
                           for idx, orbit in enumerate(img_orbit)]



#------------------------------------------------------------------------------



# APERTURE PHOTOMETRY



# Defining the output path
# ------------------------


save_path_dir = "aperture_photometry/"
if os.path.exists(save_path_dir):
    shutil.rmtree(save_path_dir)
os.mkdir(save_path_dir)

for items in obs:
    path = os.path.join(save_path_dir, items)
    os.mkdir(path)



# Performing aperture photometry
# ------------------------------


count = 0

for i,j in zip(img_orbit, imgI_coo_dat_file_orbit):
    for img_file, coo_file in zip(i,j):
        obs_id_name = img_file[-83:-59]
        episode_number = img_file[-58:-52]
        print(obs_id_name, episode_number)
        centroids = np.genfromtxt(coo_file, delimiter = ',')
        centroids = centroids - 1
        
        """ 
        Subtracting 1 from the centroids to compensate for the 1 which was 
        added in the script 'source_detection.py' to keep zero indexing.
        
        """
        
        # Loading the fits image file data
        hdu_img = fits.open(img_file)
        image = hdu_img[0].data
        
        
        # Background estimation
        binned_data = rebin(image, 64)
        zoomed_data = tile_array(binned_data, 64)
        sigma_clip = SigmaClip(sigma = 3.)
        
        # Estimating the image centroids. 
        xcentre, ycentre = centroid_com(zoomed_data > 0)
        aperture = CircularAperture((xcentre, ycentre), r = 1800)
        radius_mask = aperture.to_mask(method = "center")
        radius_mask = radius_mask.to_image(shape = ((4800, 4800)))
        radius_mask = np.logical_not(radius_mask)
        
        bkg_estimator = photutils.background.MedianBackground()
        bkg = photutils.background.Background2D(zoomed_data, (384, 384), 
                                                filter_size = (3, 3), 
                                                bkg_estimator = bkg_estimator,
                                                coverage_mask = radius_mask)
        
        
        # Performing aperture photometry on the detected soures
        aperture = photutils.aperture.CircularAperture(centroids, r = 12)
        phot_table = photutils.aperture.aperture_photometry(image - 
                                                            bkg.background, 
                                                            aperture)
        
        # calculating the error
        exp_time = hdu_img[0].header['EXP_TIME']
        aperture_sum_cps = phot_table['aperture_sum']
        error = np.sqrt(aperture_sum_cps * exp_time) / exp_time         
        
        
        # for consistent table output
        phot_table['aperture_sum'].info.format = '%.8g'
        phot_table['error'] = error
        print(phot_table)
        
        # to save the output
        phot_table.write(save_path_dir + obs_id_name + "/" + 
                         episode_number + "_aperture_CPS.csv", 
                         format = 'csv', overwrite = True)
        print("")
        hdu_img.close()
    
    count = count + 1
    print("Files completed: ", count)
    print("------------------------------------------------------------------")
    print("")



# end


