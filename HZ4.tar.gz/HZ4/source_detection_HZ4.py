import os
import shutil

import matplotlib.pyplot as plt
import numpy as np

from astropy.convolution import Gaussian2DKernel, convolve
from astropy.io import fits
from astropy.stats import sigma_clipped_stats
from glob import glob
from matplotlib import colors
from photutils.aperture import CircularAperture, RectangularAperture
from photutils.background import Background2D, MedianBackground
from photutils.centroids import centroid_com
from photutils.detection import DAOStarFinder



#------------------------------------------------------------------------------



# DEFINING FUNCTIONS


threshold_init = 40


def rebin(arr, bin_factor):
    shape = (int(arr.shape[0] / bin_factor), bin_factor,
             int(arr.shape[1] / bin_factor), bin_factor)
    binned_arr = arr.reshape(shape).mean(-1).mean(1)
    return binned_arr


def tile_array(arr, factor):
    m, n = arr.shape
    return np.repeat(np.repeat(arr, factor, axis = 1), factor, 
                     axis = 0).reshape(m * factor, n * factor)


def detect_sources_with_radius(data, threshold, window_size, num_attempts, 
                               max_attempts):    
    kernel = Gaussian2DKernel(x_stddev = 1.5)
    binned_data = rebin(data, 2)
    smoothed_data = convolve(binned_data, kernel)
    zoomed_data = tile_array(smoothed_data, 2)
    
    # Estimating the image centroids. 
    xcentre, ycentre = centroid_com(zoomed_data > 0)
    aperture = RectangularAperture((xcentre, ycentre), window_size, 
                                   window_size)
    radius_mask = aperture.to_mask(method = "center")
    radius_mask = radius_mask.to_image(shape = ((4800, 4800)))
    radius_mask = np.logical_not(radius_mask)
    
    bkg_estimator = MedianBackground()
    for_bkg_binned = rebin(data, 64)
    for_bkg_zoomed = tile_array(for_bkg_binned, 64)
    bkg = Background2D(for_bkg_zoomed, (384, 384), filter_size = (3, 3),
                       bkg_estimator = bkg_estimator,
                       coverage_mask = radius_mask)
    
    img_bkg = bkg.background
        
    
    print("Threshold set = ", threshold)
    print("Detecting sources...")  
    median_bkg = np.median(bkg.background[bkg.background > 0])
    daofind = DAOStarFinder(fwhm = 6, threshold = threshold * median_bkg,                             
                            exclude_border = True)
    sources = daofind(zoomed_data, mask = radius_mask)
    print("No. of sources detected: ", len(sources))
    

    if len(sources) > 15 and num_attempts < max_attempts:
        threshold_increase = threshold + 25
        print("Increasing threshold to ", threshold_increase)
        return detect_sources_with_radius(data, threshold_increase, 
                                          window_size, 
                                          num_attempts = num_attempts + 1, 
                                          max_attempts = max_attempts)
    
    elif len(sources) < 1 and num_attempts <= max_attempts:
        threshold_decrease = threshold - 10
        print('Decreasing threshold to ', threshold_decrease)
        return detect_sources_with_radius(data, threshold_decrease, 
                                          window_size, 
                                          num_attempts = num_attempts + 1, 
                                          max_attempts = max_attempts)
        
    elif len(sources) < 10 and num_attempts <= max_attempts:
        sources.sort('mag')
        stripped = sources['xcentroid', 'ycentroid']
        return stripped, xcentre, ycentre, threshold, img_bkg
    
    else:
        print("Maximum number of attempts to detect sources exhausted. Increase the threshold or the maximum number of attempts.")



#-----------------------------------------------------------------------------



# FETCHING THE DATA



obs_list_path = "Data_info/obs_id.txt"
with open(obs_list_path, 'r') as file:
    data = file.readlines()
file.close()


obs = [i.strip() for i in data]

img_orbit = []
total_img = 0
exp_time_threshold = 130


for i in obs:
    img = glob("Data_astrobrowse/" + i + "/*FIIP*F1I_l2img.fits.gz")
    episode_index = []
    
    if len(img) == 1:
        img_orbit.append(img)
    else:
        for index, k in enumerate(img):
            img_list = fits.open(k)
            exp_time = img_list[0].header['EXP_TIME']
            if exp_time > exp_time_threshold:
                episode_index.append(index)
        temp_arr = []
        
        """ 
        These exposure time values were removed:
        AS1C02_002T01_9000000888 uvt_12 - 69.22363
        AS1C02_002T01_9000006092 uvt_09 - 119.3006
        
        """
        
        for a in episode_index:
            temp_arr.append(img[a])
        img_orbit.append(temp_arr)


total_img = sum(len(i) for i in img_orbit)
print("Instrument coordinate images for all episodes: ", total_img)
print("______________________________________________________________________")
print("")



#------------------------------------------------------------------------------



# SOURCE DETECTION



# Defining the output path
# ------------------------


save_path_dir = "source_detection/"
if os.path.exists(save_path_dir):
    shutil.rmtree(save_path_dir)
os.mkdir(save_path_dir)

for items in obs:
    path = os.path.join(save_path_dir, items)
    os.mkdir(path)

source_bkg = save_path_dir + "source_bkg_HZ4.txt"



# Detecting sources
# -----------------


count = 0

with open(source_bkg, 'w') as file:
    for i in img_orbit:
        for j in i:
            obs_id_name = j[-51:-27]
            episode_number = j[-58:-52]
            print(obs_id_name, episode_number)
            img_list = fits.open(j)
            img_data = img_list[0].data
            
            ra = img_list[0].header['RA_PNT']
            dec = img_list[0].header['DEC_PNT']
            ra_dec_info = np.savetxt(save_path_dir + obs_id_name + "/" + 
                                     episode_number + "_ra_dec_imgI.dat", 
                                     (ra, dec))     # coordinate info    
            
            window_size = 200 * 8 
            num_attempts = 0
            max_attempts = 10
            
            stripped, xcentre, ycentre, threshold, img_bkg = detect_sources_with_radius(img_data, 
                                                                                        threshold = threshold_init, 
                                                                                        window_size = window_size, 
                                                                                        num_attempts = num_attempts, 
                                                                                        max_attempts = max_attempts)
            
            median_bkg = np.median(img_bkg[img_bkg > 0])
            
            with open(source_bkg, 'a') as file:
                file.write('%4s %4s %4s %4s \r\n' % (obs_id_name + '_' + 
                                                     episode_number, threshold, 
                                                     len(stripped), 
                                                     median_bkg))
            
            
            stripped['xcentroid'] = stripped['xcentroid'] + 1
            stripped['ycentroid'] = stripped['ycentroid'] + 1
            
            kernel = Gaussian2DKernel(x_stddev = 1.5)
            binned_data = rebin(img_data, 2)
            smoothed_data = convolve(binned_data, kernel)
            zoomed_data = tile_array(smoothed_data, 2)
            mean, median, std = sigma_clipped_stats(zoomed_data, sigma = 5., 
                                                    maxiters = 1)
            
            for_bkg_binned = rebin(img_data, 64)
            for_bkg_zoomed = tile_array(for_bkg_binned, 64)
            
            
            
            # Creating the image background map
            # ---------------------------------
            
            fig1 = plt.figure(1)
            plt.imshow(img_bkg, origin = 'lower', cmap = 'viridis', 
                       norm = colors.LogNorm(), interpolation = 'nearest')
            plt.title('Background', fuvt_12ontsize = 15)
            plt.xlabel('Sub-pixels', fontsize = 12)
            plt.ylabel('Sub-pixels', fontsize = 12)
            cbar = plt.colorbar()
            cbar.set_label('CPS', labelpad = 20, fontsize = 12)
            plt.savefig(save_path_dir + obs_id_name + "/" + episode_number + 
                        '_img_bkg.png', dpi = 150, bbox_inches = 'tight', 
                        facecolor = 'w')
            plt.clf()
            plt.close()
            
            
            # Creating the rescaled image from the .FITS file
            # -----------------------------------------------

            fig2 = plt.figure(2)
            plt.imshow(for_bkg_zoomed, cmap = 'viridis', origin = 'lower', 
                       norm = colors.LogNorm(), interpolation = 'nearest')
            plt.title('Image', fontsize = 15)
            plt.xlabel('Sub-pixels', fontsize = 12)
            plt.ylabel('Sub-pixels', fontsize = 12)
            cbar = plt.colorbar()
            cbar.set_label('CPS', labelpad = 52.5, fontsize = 12)
            plt.savefig(save_path_dir + obs_id_name + "/" + episode_number + 
                        "_img.png", dpi = 150, bbox_inches = 'tight', 
                        facecolor = 'w')
            plt.clf()
            plt.close()
            
            
            # Detections
            # ----------
            
            fig3 = plt.figure(3)
            plt.imshow(zoomed_data, cmap = 'Greys', origin = 'lower', 
                       vmax = median + 5 * std)
            positions = np.transpose((stripped['xcentroid'], 
                                      stripped['ycentroid']))
            apertures = CircularAperture(positions, r = 10.)
            apertures.plot(color = 'blue', lw = 1.5, alpha = 0.5)
            apertures = RectangularAperture((xcentre, ycentre), window_size,
                                             window_size)
            apertures.plot(color = 'red', lw = 1, alpha = 0.5)
            plt.xlabel('Sub-pixels', fontsize = 12)
            plt.ylabel('Sub-pixels', fontsize = 12)
            plt.savefig(save_path_dir + obs_id_name + "/" + episode_number + 
                        "_detections_imgI.png", dpi = 150, 
                        bbox_inches = 'tight', facecolor = 'w')
            plt.clf()
            plt.close()
            
            
            # To write to file.
            filename = (save_path_dir + obs_id_name + "/" + episode_number + 
                        '_coo_imgI.dat')
            np.savetxt(filename, stripped.as_array(), fmt = '%s', 
                       delimiter = ',')
            img_list.close()
        
        count = count + 1
        print("Files completed: ", count)
        print("")
        print("--------------------------------------------------------------")
        print("")

file.close()



# end


